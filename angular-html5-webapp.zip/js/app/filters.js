'use strict';

/* Filters */

angular.module('myApp.filters', []);
